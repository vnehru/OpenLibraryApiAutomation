package net.openlibrary.showcase.cucumber.junit.api.tests;

import java.util.ArrayList;

import net.openlibrary.showcase.cucumber.utils.ConstantValues;
import net.serenitybdd.junit.runners.SerenityRunner;
import net.thucydides.core.annotations.Title;

import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;

import com.jayway.restassured.RestAssured;
import com.jayway.restassured.http.ContentType;
import com.jayway.restassured.response.Response;

import static net.serenitybdd.rest.SerenityRest.rest;
import static org.junit.Assert.assertEquals;

@SuppressWarnings("unused")
@RunWith(SerenityRunner.class)
public class OpenLibraryApiTest {

	@BeforeClass
	public static void init() {
		RestAssured.baseURI = ConstantValues.BASEURL;
	}

	@Test
	@Title("This test is to verify Open Library  allows accessing editions of a work returns API status code as 200")
	public void verifyStatusCodeForgeteditionsofwork() {

		Response response = rest().given().when().contentType(ContentType.JSON).get("/works/OL27258W/editions.json?limit=5");
				assertEquals(200, response.getStatusCode());
	}
	
	@Test
	@Title("This test is to verify count of publishers associated with searched via opensearch API")
	public void verifyPublishersassociatedwithsearchlist() {

		Response response = rest().given().when().contentType(ContentType.JSON).get("/works/OL27258W/editions.json?limit=5");
		ArrayList<String> actualvalue = response.then().contentType(ContentType.JSON).extract().path("entries.publishers");
		System.out.println("The Total size of publishers " +  actualvalue.size());
		assertEquals(5, actualvalue.size());
	}
	
	
	@Test
	@Title("This test is to verify the get Content for Author returns API status Code as 200")
	public void verifyStatusCodeForOpenlibraryContent() {

		Response response = rest().given().when().contentType(ContentType.JSON).get("/authors/OL1A.json");
	    assertEquals(200, response.getStatusCode());
	    
	  }
	
	@Test
	@Title("This test is to verify the author name returned for searched Api content is matching with expected user name")
	public void verifyAuthorNameforopenlibarysearched() {

		Response response = rest().given().when().contentType(ContentType.JSON).get("/authors/OL1A.json");
	    String actualvalue = response.then().contentType(ContentType.JSON).extract().path("death_date");
	    System.out.println("The actual size of item is " +  actualvalue.toString());
	    assertEquals("2004", actualvalue.toString());
	  }
	
	
	@Test
	@Title("This test is to verify the author's death date returned for searched Api content is matching with expected death date")
	public void verifyAuthorsDeathdateforopenlibrarysearched() {

		Response response = rest().given().when().contentType(ContentType.JSON).get("/authors/OL1A.json");
	    String actualvalue = response.then().contentType(ContentType.JSON).extract().path("name");
	    System.out.println("The actual size of item is " +  actualvalue.toString());
	    assertEquals("Sachi Rautroy", actualvalue.toString());
	   }
	

	@Test
	@Title("This test is to verify the author's key type value returned for searched Api content is matching correctly")
	public void verifyAuthorkeytypevaluereturned() {

		Response response = rest().given().when().contentType(ContentType.JSON).get("/authors/OL1A.json");
		String actualvalue = response.then().contentType(ContentType.JSON).extract().path("type.key");
	    
	    System.out.println("The actual value of item value is " +  actualvalue.toString());
	    assertEquals("/type/author", actualvalue.toString());
	   }
	

	@Test
	@Title("This test is to verify the author's modified date value returned for searched Api content is matching correctly")
	public void verifyAuthormodifieddatetype() {

		Response response = rest().given().when().contentType(ContentType.JSON).get("/authors/OL1A.json");
		String actualvalue = response.then().contentType(ContentType.JSON).extract().path("last_modified.type");
	    
	    System.out.println("The actual value of modifieddate type is " +  actualvalue.toString());
	    assertEquals("/type/datetime", actualvalue.toString());
	   }
	
	
	
	@Test
	@Title("This test is to verify Open Library  allows accessing works of an author Returns API status code as 200")
	public void verifyStatusCodeForworksofAuthor() {

		Response response = rest().given().when().contentType(ContentType.JSON).get("/authors/OL1A/works.json");
				assertEquals(200, response.getStatusCode());
	}
	
	@Test
	@Title("This test is to verify Query Library  allows accessing works of an author and edition combination Returns API status code as 200 ")
	public void verifyStatusCodeForauthorandeditioncombinationquery() {

		Response response = rest().given().when().contentType(ContentType.JSON).get("/query.json?type=/type/edition&authors=/authors/OL1A");
				assertEquals(200, response.getStatusCode());
	}
	

	@Test
	@Title("This test is to verify Query Library  allows accessing works of an edition and works combination Returns API status code as 200")
	public void verifyStatusCodeForeditionandworkscombinationquery() {

		Response response = rest().given().when().contentType(ContentType.JSON).get("/query.json?type=/type/edition&works=/works/OL2040129W");
				assertEquals(200, response.getStatusCode());
	}
	
	
	@Test
	@Title("This test is to verify Query Library  allows accessing works of an edition and empty title  combination Returns API status code as 200")
	public void verifyStatusCodeForeditionandemptyTitlecombinationquery() {

		Response response = rest().given().when().contentType(ContentType.JSON).get("/query.json?type=/type/edition&authors=/authors/OL1A&title=");
				assertEquals(200, response.getStatusCode());
	}
	
	@Test
	@Title("This test is to verify Query Library allows accessing all properties of author via specialquery  combination Returns API status code as 200")
	public void verifyStatusCodeForallpropertiesofauthor() {

		Response response = rest().given().when().contentType(ContentType.JSON).get("/query.json?type=/type/edition&authors=/authors/OL1A&title=");
				assertEquals(200, response.getStatusCode());
	}
	
	@Test
	@Title("This test is to verify Query response allows accessing of query results for 2 entries limit  combination Returns API status code as 200")
	public void verifyStatusCodeForquerylimit() {

		Response response = rest().given().when().contentType(ContentType.JSON).get("/query.json?type=/type/edition&authors=/authors/OL1A&limit=2");
				assertEquals(200, response.getStatusCode());
	}
	
	@Test
	@Title("This test is to verify Query response allows JSON dictionary query to returns API Status code as 200")
	public void verifyStatusCodeJSONDictionaryQuery() {

		Response response = rest().given().when().contentType(ContentType.JSON).get("/query.json?query={\"type\": \"/type/edition\", \"authors\": \"/authors/OL1A\", \"title\": \"null\", \"limit\": 2}");
				assertEquals(200, response.getStatusCode());
				
				
	}
	
	@Test
	@Title("This test is to verify Query response allows invalid JSON dictionary query to returns API Status code as 400 bad request")
	public void verifyStatusCodeInvalidJSONDictionaryQuery() {

		Response response = rest().given().when().contentType(ContentType.JSON).get("/query.json?query={\"type\": \"/type/edition\", \"authors\": \"/authors/OL1A\", \"tit\": \"null\", \"limit\": 2");
				assertEquals(400, response.getStatusCode());
				
	}
	
	@Test
	@Title("This test is to verify histroy of any object by passing overloaded history parameter to url returns a stack overflow")
	public void verifyStatusCodeByPassingHistroyParameter() {

		Response response = rest().given().when().contentType(ContentType.JSON).get("/books/OL1M.json?m=history");
				assertEquals(200, response.getStatusCode());
				System.out.println("The value is " +  response.getStatusCode());
				
	}
	
	@Test
	@Title("This test is to verify histroy of any object by passing history with limit  parameter returns a 200 api response")
	public void verifyStatusCodeByPassingHistroylimitParameter() {

		Response response = rest().given().when().contentType(ContentType.JSON).get("/books/OL1M.json?m=history&limit=2&offset=1");
				assertEquals(200, response.getStatusCode());
				
	}
	
	@Test
	@Title("This test is to verify recent changes of an author by passing name and offset parameter returns a 200 api response")
	public void verifyStatusCodeByPassingNameandOffsetParameter() {

		Response response = rest().given().when().contentType(ContentType.JSON).get("/recentchanges.json?author=/people/anand&offset=20&limit=20");
				assertEquals(200, response.getStatusCode());
				
	}
	
	@Test
	@Title("This test is to verify authentication failure by posting invalid user details returns a 302 URL Redirection request ")
	public void verifyStatusCodeBypassinginvalidlogin() {

		String requestBody = "{\"header\": {\"apiName\": \"postinvalidauthentication\"},\"request\": {\"username\": \"joe\",\"password\": \"secret\"}}";

		Response response = rest().given().when().contentType(ContentType.JSON)
				.body(requestBody).post("/account/login");
           assertEquals(302, response.getStatusCode());
				
	}
	
}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	