package net.openlibrary.showcase.cucumber.utils;
import java.io.FileReader;
import java.io.Reader;
import java.util.Map;

import org.yaml.snakeyaml.Yaml;

public class YamlReader {
	
	/**
	 * @param strFile
	 * @return
	 */
	public static Map<String, Object> getYamlAsMap(String strFile) {
		Map<String, Object> map = null;
		try {
			Reader doc = new FileReader(strFile);
			Yaml yaml = new Yaml();
			map = (Map<String, Object>) yaml.load(doc);
		} catch (Exception e) {
			
		}
		return map;
	}

	/**
	 * @param object
	 * @param token
	 * @return
	 */
	public static String getMapValue(Map<String, Object> object, String token) {
		String[] st = token.split("\\.");
		return parseMap(object, token).get(st[st.length - 1]).toString();
	}
	
	/**
	 * @param object
	 * @param token
	 * @return
	 */
	public static Map<String, Object> getMapValueAsMap(Map<String, Object> object, String token) {
		String[] st = token.split("\\.");
		return (Map<String, Object>) parseMap(object, token).get(st[st.length - 1]);
	}

	private static Map<String, Object> parseMap(Map<String, Object> object,
			String token) {
		if (token.contains(".")) {
			String[] st = token.split("\\.");
			object = parseMap((Map<String, Object>) object.get(st[0]),
					token.replace(st[0] + ".", ""));
		}
		return object;
	}
}
