package net.openlibrary.showcase.cucumber.utils;

import java.io.FileReader;
import java.util.Arrays;

import au.com.bytecode.opencsv.CSVReader;

public class CSVRead {
	
	// Method for getting cell value from CSV File
    /**
     * 
     * @param filePath
     *            File Path of the CSV which contains the testData
     * @param columnNameRowNum
     *            Name of the row from which data has to be retrieved
     *            eg:UserName_1 where 1 is the row number in the csv file
     *            columnNameRowNum must always be in the form of RowName_i
     * @return
     * @throws Throwable
     */
    public static String getCellValue(String filePath, String columnNameRowNum)
	    throws Throwable {

	FileReader fileName = new FileReader(filePath);
	FileReader fileName1 = new FileReader(filePath);
	// index of the Column
	int columnIndex = 0;
	// Column Name and the Row Number
	String[] temp = columnNameRowNum.split("_");
	// Column Name
	String colName = temp[0];
	// RowNumber
	int rowNumber = Integer.parseInt(temp[1]);

	// Expected Row Contents
	String[] expectedRow = null;

	// Build reader instance
	// Default separator is comma
	// Default quote character is double quote
	// Start reading from line number 2 (line numbers start from zero)
	@SuppressWarnings("resource")
	CSVReader reader = new CSVReader(fileName, ',', '"', 0);
	@SuppressWarnings("resource")
	CSVReader readerColumn = new CSVReader(fileName1, ',', '"', 0);

	// Read CSV line by line and use the string array as you want
	String[] nextLine;
	// Read the Row which contains the column Names
	String[] rowColumnNames;
	rowColumnNames = reader.readNext();

	String firstRow = Arrays.toString(rowColumnNames);
	// Split the Row values and store them in an Array
	String[] columnName = firstRow.split(",");

	// Loop through the columns to find the index of the expected Column
	// Name
	for (int i = 0; i < columnName.length; i++) {
	    if (columnName[i].contains(colName)) {
		// System.out.println(i);
		columnIndex = i;
	    }

	}

	int j = 1;
	while ((nextLine = readerColumn.readNext()) != null) {
	    if (nextLine != null) {
		// if the row number is found, then store that row in an array
		if (j == rowNumber) {
		    expectedRow = readerColumn.readNext();
		    // System.out.println(Arrays.toString(expectedRow));
		}
		j++;
		// System.out.println(j);
		// Verifying the read data here
		// System.out.println(Arrays.toString(nextLine));
	    }
	}
	// Variable to store the obtained Row of data from the CSV file
	String obtainedRow = Arrays.toString(expectedRow);
	String[] rowValue = obtainedRow.split(",");

	int s = 0;
	for (int m = 0; m < rowValue.length; m++) {
	    if (s == columnIndex) {
		// String returnValue = rowValue[m].replaceAll("[^\\w\\s]", "");
		String returnValue1 = rowValue[m].replace("]", "");
		String returnValue = returnValue1.replace("[", "");
		return returnValue.trim();
	    }
	    s++;
	}
	return "Value does not exist in" + fileName
		+ "Verify if the value exists";

    }

}
