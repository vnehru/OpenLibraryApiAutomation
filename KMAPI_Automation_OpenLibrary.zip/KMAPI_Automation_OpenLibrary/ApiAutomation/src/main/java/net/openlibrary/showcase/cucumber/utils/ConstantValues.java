package net.openlibrary.showcase.cucumber.utils;

import java.io.File;

public class ConstantValues {

	public static final String COMMONFILEPATH = System.getProperty("user.dir")
			+ File.separator + "src" + File.separator + "test" + File.separator
			+ "resources" + File.separator + "testdata"+File.separator;
	public static final String SUBSCRIBER_FILE_PATH = System.getProperty("user.dir")
			+ File.separator + "src" + File.separator + "test" + File.separator
			+ "resources" + File.separator + "testdata"+File.separator+"subscriber"+File.separator;
	
	public static final String SUBSCRIBERTIME_FILE_PATH = System.getProperty("user.dir")
			+ File.separator + "src" + File.separator + "test" + File.separator
			+ "resources" + File.separator + "testdata"+File.separator+"subscriberTime"+File.separator;
	
	public static final String DEMOGRAPHIC_FILE_PATH = System.getProperty("user.dir")
			+ File.separator + "src" + File.separator + "test" + File.separator
			+ "resources" + File.separator + "testdata"+File.separator+"demographic"+File.separator;
	
	
	//public static final String BASEURL="http://md-bdadev-7.verizon.com:9999/palomar-api/api/analytics/subscriber";
	public static final String BASEURL="http://openlibrary.org";
}
