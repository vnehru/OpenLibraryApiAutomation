package net.openlibrary.showcase.cucumber.utils;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

public class Utils {
	
	/***
	 * 
	 * @param fileNameWithPath: Provide the full path of the Json File
	 * @param keyName:Name of the key that is needed to be retrieved from the Json File
	 * @return
	 * @throws FileNotFoundException
	 */
	public static Object getaudienceDefinitionsTestData(String fileNameWithPath,String keyName) throws FileNotFoundException{
		
		JSONParser parser = new JSONParser();
		Object obj = null;
		try {
			obj = parser.parse(new FileReader(fileNameWithPath));
			JSONObject jsonObject = (JSONObject) obj;
			return jsonObject.get(keyName);
			
		} catch (IOException e) {
			e.printStackTrace();
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return null;
	}
	
	/**
	 * This method will return a List of type String
	 * @return
	 */
	public static List<String> getValuesAsList(String value,String seaporator){
		List<String> retValues =null;
		try{
			
			String[] values =value.split(seaporator);
			return Arrays.asList(values);
			
		}catch(Throwable t){
			t.printStackTrace();
		}
		return null;
		
	}

}
