## Palomar API Automation

Run the tests with the below Maven Command:

```
mvn clean verify serenity:aggregate
```

The reports will be generated in `target/site/serenity`.
